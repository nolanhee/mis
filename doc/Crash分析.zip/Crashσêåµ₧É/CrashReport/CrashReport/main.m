//
//  main.m
//  CrashReport
//
//  Created by xiejinzhan on 14-8-6.
//  Copyright (c) 2014年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TBCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TBCAppDelegate class]));
    }
}
