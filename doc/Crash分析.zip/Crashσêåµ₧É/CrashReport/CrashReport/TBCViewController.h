//
//  TBCViewController.h
//  CrashReport
//
//  Created by xiejinzhan on 14-8-6.
//  Copyright (c) 2014年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

NSString *const TestString = @"testSting";
static int staticint = 10;

NSString *unConstString = @"unConstString";

NSString *const testString2;
static int    g_D;                    //BSS段

void c_FunTest();

@interface TBCViewController : UIViewController{
@private
    int xx_xx;
}

@property (nonatomic, retain) NSString *propertyString;

@end
