//
//  TBCViewController.m
//  CrashReport
//
//  Created by xiejinzhan on 14-8-6.
//  Copyright (c) 2014年 baidu. All rights reserved.
//

#import "TBCViewController.h"

void c_FunTest()
{
    printf("ss");
}

@interface GestureDelegate : NSObject<UIGestureRecognizerDelegate>

@end

@implementation GestureDelegate

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    return YES;
}

@end

@interface GestureTarget : NSObject

- (void)handleGesture:(UIGestureRecognizer *)gesture;

@end

@implementation GestureTarget

- (void)handleGesture:(UIGestureRecognizer *)gesture
{
    
}

@end

@interface MemoryCrash: NSObject

@property (nonatomic, assign) id delegate;

@end

@implementation MemoryCrash

@end

@interface MemoryCrashHelper: NSObject

- (void)delegateMethod;

@end

@implementation MemoryCrashHelper

- (void)delegateMethod
{
    
}

@end

@interface TBCViewController ()

@property (nonatomic, assign) dispatch_block_t block;
@property (nonatomic, copy) dispatch_block_t copyBlock;

@end
#import <objc/runtime.h>

@interface UIGestureRecognizer (Hook)

- (void)updateGestureWithEvent:(UIEvent *)event buttonEvent:(UIEvent *)ee;

@end

@implementation UIGestureRecognizer (Hook)

- (void)updateGestureWithEvent:(UIEvent *)event buttonEvent:(UIEvent *)ee
{
    self.cancelsTouchesInView= YES;
    NSLog(@"%@ \n event %@",self,event);
    [self updateGestureWithEvent:event buttonEvent:ee];
}

@end

@implementation TBCViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    dispatch_block_t globalBlock = ^{
        NSLog(@"ddddd");
    };
    globalBlock();
    
	// Do any additional setup after loading the view, typically from a nib.
    
//    Class cls = NSClassFromString(@"TBCViewControllerX");
//    
//    id obj = [[cls alloc] init];
//    
//    NSMutableArray *array = [NSMutableArray new];
//    [array addObject:obj];
//    
//    [obj release];
    
    Method method = class_getInstanceMethod([UIGestureRecognizer class], @selector(_updateGestureWithEvent:buttonEvent:));
    Method newMethod = class_getInstanceMethod([UIGestureRecognizer class], @selector(updateGestureWithEvent:buttonEvent:));
    method_exchangeImplementations(method, newMethod);
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)simCrash:(id)sender
{
    GestureTarget *target = [[GestureTarget alloc] init];
    GestureDelegate *delegate = [[GestureDelegate alloc] init];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:target action:@selector(handleGesture:)];
    tap.delegate = delegate;
    [self.view addGestureRecognizer:tap];
    [tap release];
//    [target release];
//    [delegate release];
}


- (IBAction)exc_bad_access:(id)sender
{
    id string = [[NSString alloc] initWithUTF8String:"afdasf"];
    [string release];
    dispatch_async(dispatch_get_main_queue(), ^{
        NSLog(@"%@",string);
    });
}

- (IBAction)memoryLeak_Crash:(id)sender
{
    MemoryCrash *leakObj = [[MemoryCrash alloc] init];
    MemoryCrashHelper *helper = [[MemoryCrashHelper alloc] init];
    leakObj.delegate = helper;
    
    //你的工作
    
    //忘记release leakObj了。
    //但是delegate已经释放了
    [helper release];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        //现在有事件返回了。。
        [leakObj.delegate delegateMethod];
        //crash
    });
}

-(IBAction)memoryToABRT:(id)sender
{
    //实质是一个内存问题
    id string = [[NSString alloc] initWithUTF8String:"afdasf"];
    
    //你的工作
    
    //释放了
    [string release];
    
    //模拟指针乱指
    string = [NSNumber numberWithDouble:12];
    
    NSLog(@"%d",[string length]);
}

- (void)afterCallBlock
{
    self.block();
    
    for (int i = 0; i < 100; i++) {
        @autoreleasepool {
            [[NSObject new] autorelease];
        }
    }
    int i;
    i++;
    for (int j = 100; j < 1000; j++) {
        int i= 0;
        i++;
    }
}

- (void)afterCallCopyBlock
{
    int xxxxxxxx = 1;
    NSObject *localObj = (NSObject *)xxxxxxxx;
    
    NSLog(@"%@",localObj);
}


- (IBAction)simBlockCrash:(id)sender
{
//    //模拟假的block1
//    void *v = (void *)1;
//    dispatch_block_t block = v;
//    dispatch_async(dispatch_get_global_queue(0, 0), block);
    
//    //模拟假的block2
//    void *v = (void *)1;
//    dispatch_block_t block = v;
//    self.block = block;
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [self afterCallBlock];
//    });
    
    self.copyBlock = ^{
        NSLog(@"copy Block called %@",self);
    };
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.copyBlock();
    });
    
    Block_release(_copyBlock);
}

@end
