//
//  TBCAppDelegate.h
//  CrashReport
//
//  Created by xiejinzhan on 14-8-6.
//  Copyright (c) 2014年 baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TBCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
